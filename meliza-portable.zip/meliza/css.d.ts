declare module "*.css";
